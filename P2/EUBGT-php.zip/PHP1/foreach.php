<?php

$names = array('John', 'Peter', 'Bastian');
foreach ($names as $name) {
    echo "$name <br>";
}

$names2 = array('John' => 1, 'Peter' => 2, 'Bastian' =>3);
foreach ($names2 as $name => $id) {
    echo "$name has id $id <br>";
}
