<!-- CREATE PHP WELCOME FILE -->
<?php
echo "Hello, PHP test works";
?>