<!-- CREATE EMAIL VALIDATION FORM-->
<?php

// Get the email from the form
$email = $_POST['email'];

// Check if the email is valid
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "VALID";
} else {
    echo "INVALID";
}

?>

