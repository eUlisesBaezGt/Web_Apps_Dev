<?php

echo "Longitud: " , strlen("Longitud ");

echo " -- Num de palabras: " , str_word_count(" Num de palabras ");

echo " -- Invertir: " , strrev(" Reverse ");

echo " -- Buscar: " , strpos(" Buscar ", "car");

echo " -- Reemplazar: " , str_replace("Reemplazar", "Reemplazado", "Reemplazar");
