<?php
session_start();
$_SESSION["animal"] = "eagle";
$_SESSION["food"] = "pizza";
echo "Variables saved";
