<?php
$test = "Test";
echo "This is a $test!\n";
$x = 2;
$y = 3;
echo $x + $y;
