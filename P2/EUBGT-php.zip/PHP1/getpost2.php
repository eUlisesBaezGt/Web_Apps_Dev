<?php

$post_name = $_POST['post_name'];
$post_lastname = $_POST['post_last_name'];

// Print the data to the screen
echo "Your name via POST is $post_name $post_lastname";