<?php
// Get the data from the form
$get_name = $_GET['get_name'];
$get_last_name = $_GET['get_last_name'];

// Print the data to the screen
echo "Your name via GET is $get_name $get_last_name";

