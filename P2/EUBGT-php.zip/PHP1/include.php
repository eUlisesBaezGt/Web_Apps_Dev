<?php

include 'includeBase.php';

echo $include . " " . $file;