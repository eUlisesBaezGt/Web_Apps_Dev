<?php
session_start();
?>
<?php
// Echo session variables that were set on previous page
echo "Animal: " . $_SESSION["animal"] . "<br>";
echo "Food: " . $_SESSION["food"];
?>