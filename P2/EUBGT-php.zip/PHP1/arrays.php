<?php
$langs = array("Python", "C#", "C++");
echo "I know " . $langs[0] . ", " . $langs[1] . " and " . $langs[2] . ".  ---- ";
echo "Number of elements in array: " . count($langs);
