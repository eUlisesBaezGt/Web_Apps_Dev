console.log("Hola Mundo!");
// Después del primer mensaje, se debe mostrar otro mensaje que diga "Soy el primer script"
console.log("Soy el primer script");
